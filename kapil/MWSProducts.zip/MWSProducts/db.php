<?php

session_start();

define('HOST', 'localhost');
define('USER', 'think14d_demo');
define('PASS', 'demo@153');
define('DBNM', 'think14d_mws');

function mws_mysqlConnect(){
	$mysqli = new mysqli(HOST, USER, PASS);
	if(!($mysqli)){
		die('Connection Failed to DB: '. mysqli_connect_error());
	}
	$mysqli->select_db(DBNM);
	return $mysqli;
}

