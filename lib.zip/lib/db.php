<?php

class db {

    private static $instance = NULL;

    public static function getInstance() {
        if(!self::$instance) {
            self::$instance = new PDO('mysql:dbname=markettracker123;host=localhost', 'MarkeTracker', '03-Oct-2017');
            self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
    return self::$instance;
    }
}

?>
